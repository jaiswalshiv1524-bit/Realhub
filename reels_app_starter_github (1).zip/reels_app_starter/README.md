# ReelsApp - Flutter + Firebase (Starter)

This repository contains a minimal starter project for a Reels-like app built with **Flutter** and **Firebase**.
It includes core screens: authentication, grid feed, full-screen video player, and upload flow.

## How to use
1. Install Flutter SDK: https://flutter.dev
2. Create a Firebase project and run `flutterfire configure` to generate `lib/firebase_options.dart`.
3. Update `android` SHA keys for Google sign-in if you use Google Auth.
4. Run `flutter pub get` then `flutter run`.

## Notes
- This is a starter — security rules, production transcoding, thumbnail generation, and moderation are NOT included.
- See comments in the code for next steps.
