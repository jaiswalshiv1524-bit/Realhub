// Simple VideoModel for mapping Firestore documents
import 'package:cloud_firestore/cloud_firestore.dart';

class VideoModel {
  String id;
  String ownerUid;
  String url;
  String thumbUrl;
  String caption;
  int likesCount;
  int commentsCount;
  int viewsCount;
  DateTime createdAt;

  VideoModel({required this.id, required this.ownerUid, required this.url, required this.thumbUrl, required this.caption, required this.likesCount, required this.commentsCount, required this.viewsCount, required this.createdAt});

  factory VideoModel.fromMap(String id, Map<String, dynamic> m) {
    return VideoModel(
      id: id,
      ownerUid: m['ownerUid'] ?? '',
      url: m['url'] ?? '',
      thumbUrl: m['thumbUrl'] ?? '',
      caption: m['caption'] ?? '',
      likesCount: (m['likesCount'] ?? 0),
      commentsCount: (m['commentsCount'] ?? 0),
      viewsCount: (m['viewsCount'] ?? 0),
      createdAt: (m['createdAt'] as Timestamp).toDate(),
    );
  }
}
