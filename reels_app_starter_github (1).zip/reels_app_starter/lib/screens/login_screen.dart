import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context, listen: false);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Welcome to ReelsApp', style: TextStyle(fontSize: 22)),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () => auth.signInWithGoogle(), child: Text('Sign in with Google')),
            TextButton(onPressed: () => auth.signInAnonymously(), child: Text('Continue as guest')),
          ]),
        ),
      ),
    );
  }
}
