import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

class UploadScreen extends StatefulWidget {
  @override _UploadScreenState createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  XFile? _video;
  String caption = '';
  bool _uploading = false;

  Future pickVideo() async {
    final picker = ImagePicker();
    final v = await picker.pickVideo(source: ImageSource.gallery);
    if (v == null) return;
    setState(() => _video = v);
  }

  Future upload() async {
    if (_video == null) return;
    setState(() => _uploading = true);
    final id = Uuid().v4();
    final ref = FirebaseStorage.instance.ref().child('videos/$id.mp4');
    await ref.putFile(File(_video!.path));
    final url = await ref.getDownloadURL();
    final thumbUrl = url; // placeholder - generate real thumbnail in production
    await FirebaseFirestore.instance.collection('videos').doc(id).set({
      'ownerUid': FirebaseFirestore.instance.collection('users').doc().id,
      'url': url,
      'thumbUrl': thumbUrl,
      'caption': caption,
      'likesCount': 0,
      'commentsCount': 0,
      'viewsCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
    setState(() { _uploading = false; _video = null; caption = ''; });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload')),
      body: Padding(padding: EdgeInsets.all(12), child: Column(children: [
        ElevatedButton(onPressed: pickVideo, child: Text('Pick video')),
        if (_video != null) Text('Selected: ${_video!.name}'),
        TextField(onChanged: (v) => caption = v, decoration: InputDecoration(labelText: 'Caption')),
        SizedBox(height: 12),
        _uploading ? CircularProgressIndicator() : ElevatedButton(onPressed: upload, child: Text('Upload'))
      ])),
    );
  }
}
