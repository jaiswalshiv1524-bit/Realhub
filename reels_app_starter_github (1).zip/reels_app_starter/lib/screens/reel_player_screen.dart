import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class ReelPlayerScreen extends StatefulWidget {
  final String videoId;
  ReelPlayerScreen({required this.videoId});
  @override _ReelPlayerScreenState createState() => _ReelPlayerScreenState();
}

class _ReelPlayerScreenState extends State<ReelPlayerScreen> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  Map<String, dynamic>? videoData;

  @override
  void initState() { super.initState(); _loadVideo(); }

  Future<void> _loadVideo() async {
    final doc = await FirebaseFirestore.instance.collection('videos').doc(widget.videoId).get();
    videoData = doc.data();
    final url = videoData?['url'];
    _videoController = VideoPlayerController.network(url ?? '');
    await _videoController!.initialize();
    _chewieController = ChewieController(videoPlayerController: _videoController!, autoPlay: true, looping: true, showControls: false);
    setState(() {});
    FirebaseFirestore.instance.collection('videos').doc(widget.videoId).update({'viewsCount': FieldValue.increment(1)});
  }

  @override void dispose() { _chewieController?.dispose(); _videoController?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_chewieController == null) return Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Center(child: Chewie(controller: _chewieController!)),
        Positioned(right: 12, bottom: 120, child: Column(children: [
          _actionButton(Icons.favorite_border, 'Like', () { _toggleLike(); }),
          SizedBox(height: 12),
          _actionButton(Icons.chat_bubble_outline, 'Comment', () {}),
          SizedBox(height: 12),
          _actionButton(Icons.share, 'Share', () {}),
        ])),
        Positioned(left: 12, bottom: 20, child: Text(videoData?['caption'] ?? '', style: TextStyle(color: Colors.white)))
      ]),
    );
  }

  Widget _actionButton(IconData icon, String label, VoidCallback onTap) {
    return Column(children: [GestureDetector(onTap: onTap, child: Icon(icon, color: Colors.white, size: 34)), SizedBox(height: 4), Text(label, style: TextStyle(color: Colors.white, fontSize: 12))]);
  }

  void _toggleLike() async {
    FirebaseFirestore.instance.collection('videos').doc(widget.videoId).update({'likesCount': FieldValue.increment(1)});
  }
}
